/*
@author Pawan Manglani
@version 1.1 22-SEP-2017
*/
/*
This class represent the product
*/
export class Product {
    /*store the id of product*/
    id: number;
    /*store the name of product*/
    name: String;
    /*store the price of product*/
    price: number;
}